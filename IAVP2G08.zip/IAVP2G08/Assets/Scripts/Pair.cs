﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pair : MonoBehaviour {
    public int R, C;
}
